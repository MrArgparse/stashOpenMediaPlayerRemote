(function () {
    'use strict';

    const stash = window.PluginApi;

    function getElementByXpath(xpath) {
        return document.evaluate(
            xpath,
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        ).singleNodeValue;
    }

    function waitForElementClass(className, callback) {
        const existing = document.querySelector(`.${className}`);

        if (existing) {
            callback(existing);
            return;
        }

        const observer = new MutationObserver(() => {
            const element = document.querySelector(`.${className}`);

            if (element) {
                observer.disconnect();
                callback(element);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    function safeDecodeURIComponent(value) {
        try {
            return decodeURIComponent(value);
        } catch (e) {
            return value;
        }
    }

    function isLikelyWindowsPlayer(mediaPlayerPath) {
        const p = (mediaPlayerPath || '').trim();
        return /^[A-Za-z]:\\/.test(p) || p.includes('\\');
    }

    function toCanonicalPaths(rawValue, preferWindowsNative) {
        const raw = (rawValue || '').trim();

        if (!raw) {
            return {
                nativePath: raw,
                fileUrl: raw
            };
        }

        const decodedRaw = safeDecodeURIComponent(raw);

        if (/^file:\/\//i.test(decodedRaw)) {
            try {
                const url = new URL(decodedRaw);
                const host = url.hostname;
                const pathname = safeDecodeURIComponent(
                    url.pathname || ''
                );

                if (host) {
                    const uncSlash =
                        `//${host}${pathname}`;

                    return {
                        nativePath: preferWindowsNative
                            ? uncSlash.replace(/\//g, '\\')
                            : uncSlash,
                        fileUrl:
                            `file:${encodeURI(uncSlash)}`
                    };
                }

                let localPath = pathname;

                if (/^\/[A-Za-z]:\//.test(localPath)) {
                    localPath = localPath.substring(1);

                    return {
                        nativePath: preferWindowsNative
                            ? localPath.replace(/\//g, '\\')
                            : localPath,
                        fileUrl:
                            `file:///${encodeURI(
                                localPath.replace(/\\/g, '/')
                            )}`
                    };
                }

                return {
                    nativePath: localPath,
                    fileUrl:
                        `file://${encodeURI(localPath)}`
                };
            } catch (e) {
                // ignore
            }
        }

        if (/^smb:\/\//i.test(decodedRaw)) {
            try {
                const url = new URL(decodedRaw);

                const uncSlash =
                    `//${url.hostname}${safeDecodeURIComponent(url.pathname || '')}`;

                return {
                    nativePath: preferWindowsNative
                        ? uncSlash.replace(/\//g, '\\')
                        : uncSlash,
                    fileUrl:
                        `file:${encodeURI(uncSlash)}`
                };
            } catch (e) {
                // ignore
            }
        }

        if (/^(\\\\|\/\/)/.test(decodedRaw)) {
            const uncSlash =
                decodedRaw
                    .replace(/^\\\\/, '//')
                    .replace(/\\/g, '/');

            return {
                nativePath: preferWindowsNative
                    ? uncSlash.replace(/\//g, '\\')
                    : uncSlash,
                fileUrl:
                    `file:${encodeURI(uncSlash)}`
            };
        }

        if (/^[A-Za-z]:[\\/]/.test(decodedRaw)) {
            const slashPath =
                decodedRaw.replace(/\\/g, '/');

            return {
                nativePath: decodedRaw,
                fileUrl:
                    `file:///${encodeURI(slashPath)}`
            };
        }

        if (decodedRaw.startsWith('/')) {
            return {
                nativePath: decodedRaw,
                fileUrl:
                    `file://${encodeURI(decodedRaw)}`
            };
        }

        return {
            nativePath: decodedRaw,
            fileUrl: decodedRaw
        };
    }

    async function openMediaPlayerTask(path) {
        const configResult =
            await PluginApi.utils.StashService
                .getClient()
                .query({
                    query:
                        PluginApi.GQL.ConfigurationDocument,
                    fetchPolicy: "network-only"
                });
            
        const plugins =
            configResult.data.configuration.plugins;

        const settings = {
            ...(plugins.stashOpenMediaPlayer || {}),
            ...(plugins.stashOpenMediaPlayerRemote || {})
        };

        const prefixMode =
            settings.fileUrlPrefixMode || "auto";

        const mediaPlayerPath =
            (settings.mediaPlayerPath || '').trim();

        const useRemoteProtocol =
            settings.useRemoteProtocol === true;

        const pathMapFrom =
            (settings.pathMapFrom || '').trim();

        const pathMapTo =
            (settings.pathMapTo || '').trim();

        const canonical =
            toCanonicalPaths(
                path,
                isLikelyWindowsPlayer(mediaPlayerPath)
            );

        let filePath = canonical.nativePath;
        let useFileUrl = false;

        if (useRemoteProtocol) {
            useFileUrl = false;
        } else if (prefixMode === 'keep') {
            useFileUrl = true;
        } else if (prefixMode === 'remove') {
            useFileUrl = false;
        } else {
            const lower =
                mediaPlayerPath.toLowerCase();

            if (lower.includes('vlc')) {
                useFileUrl = true;
            } else if (lower.includes('mpc')) {
                useFileUrl = false;
            } else {
                useFileUrl = /^file:\/\//i.test(path);
            }
        }

        filePath =
            useFileUrl
                ? canonical.fileUrl
                : canonical.nativePath;

        if (pathMapFrom && pathMapTo) {
            const escaped =
                pathMapFrom.replace(
                    /[.*+?^${}()|[\]\\]/g,
                    '\\$&'
                );

            filePath =
                filePath.replace(
                    new RegExp(`^${escaped}`, 'i'),
                    pathMapTo
                );
        }

        if (settings.incrementPlayCount === true) {
            const match =
                location.pathname.match(
                    /\/scenes\/(\d+)/
                );
            
            if (match) {
                try {
                    await PluginApi.utils.StashService
                        .getClient()
                        .mutate({
                            mutation:
                                PluginApi.GQL.SceneAddPlayDocument,
                            variables: {
                                id: match[1]
                            },
                            refetchQueries: [
                                {
                                    query:
                                        PluginApi.GQL.FindSceneDocument,
                                    variables: {
                                        id: match[1]
                                    }
                                }
                            ]
                        });
                } catch (err) {
                    console.error(
                        "Failed to increment play count:",
                        err
                    );
                }
            }
        }

        if (useRemoteProtocol) {
            window.location.href =
                `stashopenmediaplayerremote://open?player=${encodeURIComponent(mediaPlayerPath)}&path=${encodeURIComponent(filePath)}`;

            return;
        }

        await PluginApi.utils.StashService.getClient().mutate({
            mutation: PluginApi.GQL.RunPluginTaskDocument,
            variables: {
                plugin_id: "stashOpenMediaPlayerRemote",
                task_name: "Open in Media Player",
                args_map: {
                    path: filePath,
                    mediaPlayerPath: mediaPlayerPath
                }
            }
        });
    }

    stash.openMediaPlayerTask =
        openMediaPlayerTask;

    function getSceneFilePath() {
        const dd =
            getElementByXpath(
                "//dt[text()='Path']/following-sibling::dd"
            );

        if (!dd) {
            return null;
        }

        const link = dd.querySelector("a");

        if (link) {
            return link.href;
        }

        const input =
            dd.querySelector("input, textarea");

        if (input) {
            return (
                input.value ||
                input.getAttribute("value") ||
                null
            );
        }

        const text =
            dd.textContent?.trim();

        return text || null;
    }

    function ensureMediaPlayerToolbarButton() {
        const toolbar =
            document.querySelector('.scene-toolbar');

        if (!toolbar) {
            return;
        }

        if (
            toolbar.querySelector(
                '.open-media-player-btn'
            )
        ) {
            return;
        }

        const btn =
            document.createElement('button');

        btn.type = 'button';
        btn.title =
            'Open in External Player';

        btn.className =
            'minimal open-media-player-btn btn btn-secondary';

        btn.innerHTML =
            '<svg data-prefix="fas" data-icon="external-link" class="svg-inline--fa fa-external-link fa-icon" role="img" viewBox="0 0 512 512" aria-hidden="true" width="1em" height="1em"><path fill="currentColor" d="M432 320h-32a16 16 0 0 0-16 16v112H80V160h112a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16H64a64 64 0 0 0-64 64v304a64 64 0 0 0 64 64h368a64 64 0 0 0 64-64V336a16 16 0 0 0-16-16zM488 0H360a24 24 0 0 0-17 41l30 30L201 252a24 24 0 0 0 0 34l22 22a24 24 0 0 0 34 0L409 127l30 30A24 24 0 0 0 488 140V12a12 12 0 0 0-12-12z"></path></svg>';

        btn.addEventListener(
            'click',
            async function (e) {
                e.preventDefault();

                const path =
                    getSceneFilePath();

                if (!path) {
                    return;
                }

                await openMediaPlayerTask(path);
            }
        );

        const wrapper = document.createElement('span');
        wrapper.appendChild(btn);

        const viewCount = toolbar.querySelector(
            '.count-button.increment-only'
        );

        if (viewCount) {
            const container = viewCount.closest('span');
        
            if (container && container.parentNode) {
                container.parentNode.insertBefore(
                    wrapper,
                    container
                );
                return;
            }
        }

        toolbar.appendChild(wrapper);
    }

    function watchSceneChanges() {
        let lastPath = location.pathname;
    
        setInterval(() => {
            if (location.pathname !== lastPath) {
                lastPath = location.pathname;
            
                if (location.pathname.startsWith('/scenes/')) {
                    waitForElementClass(
                        'scene-toolbar',
                        ensureMediaPlayerToolbarButton
                    );
                }
            }
        }, 100);
    }

    watchSceneChanges();

    waitForElementClass(
        'scene-file-info',
        function () {
            ensureMediaPlayerToolbarButton();
        }
    );
})();